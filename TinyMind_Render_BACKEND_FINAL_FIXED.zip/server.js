const express = require("express");
const cors = require("cors");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 10000;

app.use(cors({
  origin: "*",
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));
app.options("*", cors());
app.use(express.json({ limit: "25mb" }));

const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const hasOpenAI = Boolean(process.env.OPENAI_API_KEY);

const openai = hasOpenAI
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

function fallbackScript(idea, language, ageRange, style) {
  return `Título: Dino aprende a compartir

Idea: ${idea}

En un valle colorido vivía Dino, un pequeño dinosaurio que amaba sus juguetes. Tenía carritos, bloques, pelotas y figuras de madera. Cada mañana jugaba feliz, pero casi siempre lo hacía solo.

Un día llegaron sus amigos Tina y Max. Tina sonrió y dijo: “Dino, ¿podemos jugar contigo?” Max levantó una pelota azul y agregó: “Podemos crear una aventura juntos.”

Dino abrazó sus juguetes y respondió: “No, son míos.” Sus amigos se pusieron tristes y se sentaron lejos. Dino siguió jugando, pero pronto notó que algo faltaba. Su torre era alta, pero nadie aplaudía. Su carrito era rápido, pero nadie corría con él. Sus rugidos eran graciosos, pero nadie se reía.

De pronto, el viento empujó la pelota de Max hacia el río. Max gritó: “¡Mi pelota!” Dino vio que su amigo estaba preocupado. Dejó sus juguetes, tomó una rama larga y con cuidado empujó la pelota hasta la orilla.

Max sonrió: “Gracias, Dino. Puedes jugar con mi pelota.” Dino se sorprendió. Max compartía con él aunque Dino no había compartido antes.

Dino miró sus juguetes y dijo: “Perdón. Pensé que compartir era perder mis cosas, pero ahora entiendo que compartir hace el juego más divertido.”

Tina, Max y Dino construyeron una ciudad con bloques, hicieron carreras y jugaron con la pelota. El valle se llenó de risas.

Al final, Dino aprendió una gran lección: los juguetes son especiales, pero compartir con amigos hace que la diversión sea mucho más grande.

Edad: ${ageRange}
Idioma: ${language}
Estilo visual: ${style}`;
}

app.get("/", (req, res) => {
  res.json({
    ok: true,
    app: "TinyMind Kids AI Render Server",
    status: "live",
    model: MODEL,
    openaiConfigured: hasOpenAI,
    routes: [
      "GET /api/health",
      "POST /api/create-script",
      "POST /api/create-scenes",
      "POST /api/chat",
      "POST /api/render-video"
    ]
  });
});

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    status: "live",
    openaiConfigured: hasOpenAI,
    model: MODEL
  });
});

app.post("/api/create-script", async (req, res) => {
  const {
    idea = "Un dinosaurio pequeño aprende a compartir sus juguetes con sus amigos",
    language = "español",
    ageRange = "4-7",
    style = "3D cartoon premium tipo película infantil",
    duration = 180
  } = req.body || {};

  try {
    if (!openai) {
      return res.json({
        ok: true,
        mode: "fallback-no-openai-key",
        script: fallbackScript(idea, language, ageRange, style)
      });
    }

    const prompt = `Crea un guion infantil seguro para YouTube Kids.
Idea: ${idea}
Idioma: ${language}
Edad: ${ageRange}
Duración: ${duration} segundos
Estilo visual: ${style}

Reglas:
- Contenido seguro para niños.
- Sin violencia fuerte, miedo fuerte, política, temas adultos ni lenguaje inapropiado.
- Narrador, diálogos cortos y moraleja.
- Devuelve solo el guion listo para copiar.`;

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: "Eres un guionista experto en videos infantiles educativos y seguros." },
        { role: "user", content: prompt }
      ],
      temperature: 0.75
    });

    const script = response.choices?.[0]?.message?.content || fallbackScript(idea, language, ageRange, style);

    res.json({ ok: true, mode: "openai", script });
  } catch (error) {
    res.json({
      ok: true,
      mode: "fallback-openai-error",
      openaiError: error.message,
      script: fallbackScript(idea, language, ageRange, style)
    });
  }
});

app.post("/api/create-scenes", async (req, res) => {
  res.json({
    ok: true,
    title: "Dino aprende a compartir",
    durationSeconds: 180,
    scenes: [
      { number: 1, duration: 12, title: "El valle colorido", narration: "Dino despierta feliz en su valle.", visualPrompt: "small cute green dinosaur in colorful valley, 3D cartoon premium" },
      { number: 2, duration: 12, title: "Llegan los amigos", narration: "Tina y Max quieren jugar con Dino.", visualPrompt: "three cute baby dinosaurs with toys, friendly, colorful 3D cartoon" }
    ]
  });
});

app.post("/api/chat", async (req, res) => {
  const message = req.body?.message || "";
  res.json({ ok: true, reply: `TinyMind recibió: ${message}` });
});

app.post("/api/render-video", async (req, res) => {
  res.json({
    ok: true,
    status: "ready",
    message: "Endpoint preparado para conectar FFmpeg/Remotion en la siguiente fase."
  });
});

app.listen(PORT, () => {
  console.log(`TinyMind FINAL FIXED backend running on port ${PORT}`);
});
